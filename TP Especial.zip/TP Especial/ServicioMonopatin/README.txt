Link Github: https://github.com/Sofiamondello04/ArquitecturasWeb

Link Collection Postman: https://crimson-space-35607.postman.co/workspace/New-Team-Workspace~6fef3d4a-5094-40a6-ba02-382b8e162da2/collection/24393112-7dedea31-0ffa-402d-933c-686f6ea57d95?action=share&creator=24393112

• Registrar monopatín en mantenimiento (debe marcarse como no disponible para su uso: Metodo POST: http://localhost:8081/api/v1/monopatin con estado "Mantenimiento" OK
• Registrar fin de mantenimiento de monopatín: Metodo PUT: http://localhost:8081/api/v1/monopatin/{id} OK
• Ubicar monopatín en parada (opcional)
• Agregar monopatín: Metodo POST: http://localhost:8081/api/v1/monopatin OK
• Quitar monopatín: Metodo DELETE: http://localhost:8081/api/v1/monopatin/{id} OK
• Registrar parada: Metodo POST: http://localhost:8081/api/v1/parada OK
• Quitar parada: Metodo DELETE: http://localhost:8081/api/v1/parada/{id} OK
• Definir precio: Metodo POST: http://localhost:8081/api/v1/tarifa OK
• Definir tarifa extra para reinicio por pausa extensa Metodo POST: http://localhost:8081/api/v1/tarifa OK
• Anular cuenta: BER/MAURO
• Generar reporte de uso de monopatines por kilómetros
• Generar reporte de uso de monopatines por tiempo con pausas
• Generar reporte de uso de monopatines por tiempo sin pausas
