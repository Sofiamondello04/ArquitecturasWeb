package com.example.demo.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ViajeResponseRest extends ResponseRest {
	
	private ViajeResponse viajeResponse = new ViajeResponse();

}