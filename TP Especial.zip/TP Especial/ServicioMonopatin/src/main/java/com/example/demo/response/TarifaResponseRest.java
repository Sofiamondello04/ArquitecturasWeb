package com.example.demo.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TarifaResponseRest extends ResponseRest {
	
	private TarifaResponse tarifaResponse = new TarifaResponse();

}