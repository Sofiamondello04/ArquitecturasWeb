package com.example.demo.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MonopatinResponseRest extends ResponseRest {
	
	private MonopatinResponse monopatinResponse = new MonopatinResponse();

}