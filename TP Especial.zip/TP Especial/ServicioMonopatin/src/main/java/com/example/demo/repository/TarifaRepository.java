package com.example.demo.repository;


import com.example.demo.model.Tarifa;



import org.springframework.data.repository.CrudRepository;



public interface TarifaRepository extends CrudRepository<Tarifa, Long> {
	
	

	
}