package com.example.demo.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ParadaResponseRest extends ResponseRest {
	
	private ParadaResponse paradaResponse = new ParadaResponse();

}