package com.example.demo.repository;



import com.example.demo.model.Parada;

import org.springframework.data.repository.CrudRepository;



public interface ParadaRepository extends CrudRepository<Parada, Long> {
	
	

	
}