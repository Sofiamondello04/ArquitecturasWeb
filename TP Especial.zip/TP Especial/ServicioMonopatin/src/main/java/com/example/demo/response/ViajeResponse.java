package com.example.demo.response;

import java.util.List;

import com.example.demo.model.Viaje;

import lombok.Data;


@Data
public class ViajeResponse {
	
	private List<Viaje> viaje; 

}