package com.example.microusuarios.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsuarioResponseRest extends ResponseRest {
	
	private UsuarioResponse usuarioResponse = new UsuarioResponse();

}