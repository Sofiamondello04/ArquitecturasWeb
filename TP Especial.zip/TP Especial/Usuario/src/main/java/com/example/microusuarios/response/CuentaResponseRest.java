package com.example.microusuarios.response;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CuentaResponseRest extends ResponseRest{
	
	private CuentaResponse cuentaResponse = new CuentaResponse();
}
